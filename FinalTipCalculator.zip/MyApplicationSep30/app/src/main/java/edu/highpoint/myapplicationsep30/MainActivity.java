package edu.highpoint.myapplicationsep30;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;

public class MainActivity extends AppCompatActivity {
    Button buttonTipPlus;
    Button buttonTipMinus;
    Button buttonCalculate;
    TextView textViewBillAmount;
    TextView textViewTipPercent;
    TextView textViewTipAmount;
    TextView textViewTotal;
    EditText editTextNumberSignedTipPercent;
    EditText editTextNumberDecimalBillAmount;
    EditText editTextNumberDecimalTipAmount;
    EditText editTextNumberDecimalTotal;

    Double BillAmount; //check correct input, null, too many, letters etc
    Integer TipPercent; //check correct input, null, too many, letters etc
    Double TipAmount;
    Double Total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonTipPlus = (Button) findViewById(R.id.buttonTipPlus);
        buttonTipMinus = (Button) findViewById(R.id.buttonTipMinus);
        buttonCalculate = (Button) findViewById(R.id.buttonCalculate);
        textViewBillAmount = (TextView) findViewById(R.id.textViewBillAmount);
        textViewTipPercent = (TextView) findViewById(R.id.textViewTipPercent);
        textViewTipAmount = (TextView) findViewById(R.id.textViewTipAmount);
        textViewTotal = (TextView) findViewById(R.id.textViewTotal);
        editTextNumberSignedTipPercent = (EditText) findViewById(R.id.editTextNumberSignedTipPercent);
        editTextNumberDecimalBillAmount = (EditText) findViewById(R.id.editTextNumberDecimalBillAmount);
        editTextNumberDecimalTipAmount = (EditText) findViewById(R.id.editTextNumberDecimalTipAmount);
        editTextNumberDecimalTotal = (EditText) findViewById(R.id.editTextNumberDecimalTotal);

        BillAmount = 0.00; //check for null and incorrect
        TipPercent = 15; //check for null and incorrect
        TipAmount = 0.15;
        Total = 0.00;

        if (editTextNumberSignedTipPercent != null ) {
            editTextNumberSignedTipPercent.setText(TipPercent.toString() + " %");
        }
    }

    public void IncreaseTip(View view) {
        TipPercent = TipPercent + 1;
        editTextNumberSignedTipPercent.setText(TipPercent.toString()+" %");
    }

    public void DecreaseTip(View view) {
        TipPercent = TipPercent - 1;
        editTextNumberSignedTipPercent.setText(TipPercent.toString()+" %");
    }

    public void CalculateTip(View view) {
        if(editTextNumberDecimalBillAmount.getText().toString().matches(""))
            BillAmount = 0.00;
        else
            BillAmount = Double.parseDouble(editTextNumberDecimalBillAmount.getText().toString());

        // initiate a Switch
        Switch simpleSwitch = (Switch) findViewById(R.id.switchRoundUp);
        // check current state of a Switch (true or false).
        Boolean switchState = simpleSwitch.isChecked();

        if(switchState && editTextNumberDecimalTotal != null && editTextNumberDecimalTipAmount != null)
        {
            TipAmount = BillAmount * TipPercent / 100;

            Total = BillAmount + TipAmount;
            editTextNumberDecimalTotal.setText("$" + Total.toString());

            BigDecimal bdTotalAmount = BigDecimal.valueOf(Total);
            bdTotalAmount = bdTotalAmount.setScale(0, RoundingMode.UP);
            double upTotalAmount = bdTotalAmount.floatValue();

            editTextNumberDecimalTotal.setText("$" + bdTotalAmount.toString());

            TipAmount = upTotalAmount - BillAmount;

            BigDecimal bdTipAmount = BigDecimal.valueOf(TipAmount);
            bdTipAmount = bdTipAmount.setScale(2, RoundingMode.HALF_UP);
            double upTipAmount = bdTipAmount.floatValue();

            editTextNumberDecimalTipAmount.setText("$" + bdTipAmount.toString());
        } else {

            TipAmount = BillAmount * TipPercent / 100;

            BigDecimal bdTipAmount = BigDecimal.valueOf(TipAmount);
            bdTipAmount = bdTipAmount.setScale(2, RoundingMode.HALF_UP);
            double upTipAmount = bdTipAmount.floatValue();

            editTextNumberDecimalTipAmount.setText("$" + TipAmount.toString());

            Total = BillAmount + TipAmount;

            BigDecimal bdTotalAmount = BigDecimal.valueOf(Total);
            bdTotalAmount = bdTotalAmount.setScale(2, RoundingMode.HALF_UP);
            double upTotalAmount = bdTotalAmount.floatValue();

            editTextNumberDecimalTotal.setText("$" + Total.toString());
        }
    }
}